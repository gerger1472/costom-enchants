CustomEnchants - Full project (generated)
---------------------------------------

This archive contains a Fabric mod project skeleton for Minecraft 1.21.1 with
many custom enchantments templates and resources. It is intended to be built
on a machine with Java 17 and Gradle.

How to build:
1. Extract this archive.
2. Open a terminal in the project root.
3. Run ./gradlew build (or gradlew.bat build on Windows).
4. Output JAR will be in build/libs/

If you want me to run a GitHub Actions workflow to build and give you the artifact,
tell me and I will prepare the workflow files and (if you allow) push to a repo.
