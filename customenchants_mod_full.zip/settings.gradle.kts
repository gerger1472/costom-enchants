rootProject.name = "customenchants_mod_full"
