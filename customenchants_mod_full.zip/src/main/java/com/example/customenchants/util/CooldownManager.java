package com.example.customenchants.util;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.UUID;
public class CooldownManager {
    private static final Map<UUID, Long> map = new ConcurrentHashMap<>();
    public static void set(UUID id, long millis) { map.put(id, System.currentTimeMillis()+millis); }
    public static boolean ready(UUID id) { Long t = map.get(id); if (t==null) return true; return System.currentTimeMillis()>t; }
}
