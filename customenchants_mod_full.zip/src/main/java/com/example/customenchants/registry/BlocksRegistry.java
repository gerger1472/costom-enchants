package com.example.customenchants.registry;

import net.minecraft.block.Block;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.util.Identifier;
import net.minecraft.registry.Registry;
import net.minecraft.registry.Registries;
import com.example.customenchants.ModMain;

public class BlocksRegistry {
    public static Block UPGRADED_ENCHANTER;

    public static void register() {
        UPGRADED_ENCHANTER = Registry.register(Registries.BLOCK, new Identifier(ModMain.MODID, "upgraded_enchanter"),
            new net.minecraft.block.Block(net.minecraft.block.AbstractBlock.Settings.of(net.minecraft.block.Material.METAL)));
        Registry.register(Registries.ITEM, new Identifier(ModMain.MODID, "upgraded_enchanter"),
            new BlockItem(UPGRADED_ENCHANTER, new Item.Settings().group(net.minecraft.item.ItemGroup.DECORATIONS)));
    }
}
