package com.example.customenchants;

import net.fabricmc.api.ModInitializer;
import com.example.customenchants.registry.EnchantmentsRegistry;
import com.example.customenchants.registry.BlocksRegistry;
import com.example.customenchants.event.EnchantEventHandlers;

public class ModMain implements ModInitializer {
    public static final String MODID = "customenchants";

    @Override
    public void onInitialize() {
        EnchantmentsRegistry.register();
        BlocksRegistry.register();
        EnchantEventHandlers.register();
        System.out.println("[CustomEnchants] initialized");
    }
}
