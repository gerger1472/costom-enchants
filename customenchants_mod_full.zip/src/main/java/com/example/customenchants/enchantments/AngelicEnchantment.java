package com.example.customenchants.enchantments;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.enchantment.EnchantmentTarget;

public class AngelicEnchantment extends Enchantment {
    public AngelicEnchantment(Rarity weight, EquipmentSlot slot) {
        super(weight, EnchantmentTarget.ALL, new EquipmentSlot[]{slot});
    }
    @Override public int getMinPower(int level) { return 1; }
    @Override public int getMaxLevel() { return 6; }
}
