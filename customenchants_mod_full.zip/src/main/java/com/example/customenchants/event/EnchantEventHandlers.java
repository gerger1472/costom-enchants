package com.example.customenchants.event;

import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ExperienceOrbEntity;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.world.World;
import net.minecraft.util.math.BlockPos;
import net.minecraft.block.Blocks;
import net.minecraft.block.BlockState;
import net.minecraft.sound.SoundEvents;
import net.minecraft.sound.SoundCategory;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.entity.passive.IronGolemEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.Entity;

import com.example.customenchants.registry.EnchantmentsRegistry;
import com.example.customenchants.ModMain;

import java.util.Random;

public class EnchantEventHandlers {
    private static final Random RANDOM = new Random();

    public static void register() {
        AttackEntityCallback.EVENT.register((player, world, hand, target, hit) -> {
            if (world.isClient) return net.fabricmc.fabric.api.event.player.AttackEntityCallback.ActionResult.PASS;
            ItemStack main = player.getMainHandStack();

            // Thunderstrike example
            int t = EnchantmentHelper.getLevel(EnchantmentsRegistry.THUNDERSTRIKE, main);
            if (t > 0 && world instanceof ServerWorld) {
                int chance = 20 * t;
                if (RANDOM.nextInt(100) < chance) {
                    ServerWorld sw = (ServerWorld) world;
                    sw.spawnEntity(new net.minecraft.entity.LightningEntity(world, target.getX(), target.getY(), target.getZ(), true));
                    if (target instanceof LivingEntity) {
                        float base = (float) player.getAttributeInstance(net.minecraft.entity.attribute.EntityAttributes.GENERIC_ATTACK_DAMAGE).getValue();
                        float extra = Math.max(1.0f, base * 0.05f);
                        ((LivingEntity) target).damage(DamageSource.player(player), extra);
                    }
                }
            }

            // Echo sound
            int e = EnchantmentHelper.getLevel(EnchantmentsRegistry.ECHO, main);
            if (e > 0) {
                int chance = 25 * e;
                if (RANDOM.nextInt(100) < chance) {
                    world.playSound(null, target.getBlockPos(), SoundEvents.ENTITY_GHAST_SCREAM, SoundCategory.PLAYERS, 1.0f, 1.0f);
                }
            }

            // Lifesteal
            int ls = EnchantmentHelper.getLevel(EnchantmentsRegistry.LIFESTEAL, main);
            if (ls > 0 && target instanceof LivingEntity) {
                int chance = Math.min(70, 15 * ls);
                if (RANDOM.nextInt(100) < chance) {
                    player.heal(1.0f * ls);
                }
            }

            // Status procs handled elsewhere for brevity
            return net.fabricmc.fabric.api.event.player.AttackEntityCallback.ActionResult.PASS;
        });

        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, be) -> {
            if (world.isClient) return;
            ItemStack tool = player.getMainHandStack();

            // Experience
            int xp = EnchantmentHelper.getLevel(EnchantmentsRegistry.EXPERIENCE, tool);
            if (xp > 0) {
                int baseXp = state.getBlock().getExperienceWhenMined();
                if (baseXp > 0) {
                    int extra = baseXp * xp;
                    world.spawnEntity(new ExperienceOrbEntity(world, pos.getX()+0.5, pos.getY()+0.5, pos.getZ()+0.5, extra));
                }
            }

            // Smelting (simple mapping)
            int sm = EnchantmentHelper.getLevel(EnchantmentsRegistry.SMELTING, tool);
            if (sm > 0) {
                int chance = 30 * sm;
                if (RANDOM.nextInt(100) < chance) {
                    if (state.getBlock() == Blocks.IRON_ORE) {
                        net.minecraft.item.ItemScatterer.spawn(world, pos, new net.minecraft.item.ItemStack(net.minecraft.item.Items.IRON_INGOT));
                    } else if (state.getBlock() == Blocks.GOLD_ORE) {
                        net.minecraft.item.ItemScatterer.spawn(world, pos, new net.minecraft.item.ItemStack(net.minecraft.item.Items.GOLD_INGOT));
                    } else if (state.getBlock() == Blocks.ANCIENT_DEBRIS) {
                        net.minecraft.item.ItemScatterer.spawn(world, pos, new net.minecraft.item.ItemStack(net.minecraft.item.Items.NETHERITE_SCRAP));
                    } else if (state.getBlock() == Blocks.SAND) {
                        net.minecraft.item.ItemScatterer.spawn(world, pos, new net.minecraft.item.ItemStack(net.minecraft.item.Items.GLASS));
                    } else if (state.getBlock() == Blocks.COPPER_ORE) {
                        net.minecraft.item.ItemScatterer.spawn(world, pos, new net.minecraft.item.ItemStack(net.minecraft.item.Items.COPPER_INGOT));
                    }
                }
            }

            // Drill 3x3 (simplified)
            int drill = EnchantmentHelper.getLevel(EnchantmentsRegistry.DRILL, tool);
            if (drill > 0) {
                int radius = Math.min(1 + drill/2, 1);
                for (int dx=-radius; dx<=radius; dx++) for (int dy=-radius; dy<=radius; dy++) for (int dz=-radius; dz<=radius; dz++) {
                    net.minecraft.util.math.BlockPos p2 = pos.add(dx, dy, dz);
                    if (!p2.equals(pos) && !world.getBlockState(p2).isAir()) {
                        world.breakBlock(p2, true, player);
                    }
                }
            }
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (ServerPlayerEntity sp : server.getPlayerManager().getPlayerList()) {
                // helmet effects: clarity, mermaid, eater
                ItemStack head = sp.getEquippedStack(EquipmentSlot.HEAD);
                if (EnchantmentHelper.getLevel(EnchantmentsRegistry.CLARITY, head) > 0) {
                    sp.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 220, 0, false, false, true));
                }
                if (EnchantmentHelper.getLevel(EnchantmentsRegistry.MERMAID, head) > 0) {
                    sp.addStatusEffect(new StatusEffectInstance(StatusEffects.WATER_BREATHING, 220, 0, false, false, true));
                }
                int eater = EnchantmentHelper.getLevel(EnchantmentsRegistry.EATER, head);
                if (eater > 0 && sp.age % 40 == 0) {
                    sp.getHungerManager().add(1, 0.1F);
                }

                // boots
                ItemStack boots = sp.getEquippedStack(EquipmentSlot.FEET);
                if (EnchantmentHelper.getLevel(EnchantmentsRegistry.GEARS, boots) > 0) {
                    int lvl = EnchantmentHelper.getLevel(EnchantmentsRegistry.GEARS, boots);
                    sp.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 220, Math.max(0, lvl-1), false, false, true));
                }
                if (EnchantmentHelper.getLevel(EnchantmentsRegistry.STRIDER, boots) > 0) {
                    net.minecraft.util.math.BlockPos p = sp.getBlockPos();
                    if (sp.world.getBlockState(p).getBlock() == Blocks.LAVA && sp.world instanceof ServerWorld) {
                        sp.world.setBlockState(p, Blocks.OBSIDIAN.getDefaultState());
                    }
                }
            }
        });
    }
}
